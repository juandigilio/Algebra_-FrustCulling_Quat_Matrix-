using UnityEngine;

[System.Serializable]
public class Room : MonoBehaviour
{
    [SerializeField] public int room { get; set; }

    //public Room(int room)
    //{
    //    this.room = room;
    //}

}
