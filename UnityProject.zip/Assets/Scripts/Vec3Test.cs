using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using MathDebbuger;

using EjerciciosAlgebra;

public class Vec3Test : MonoBehaviour
{

    private void Start()
    {
        //MathDebbuger.Vector3Debugger.AddVector(Vector3.zero, "Zero");
        //MathDebbuger.Vector3Debugger.AddVector(Vector3.one * 5, "One");

        
    }
}
